<?php
$pageTitle = 'Farm Store';
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/weather.php';

$pdo = getDB();

// Farm profile (the single farm owner)
$ownerStmt = $pdo->query("SELECT * FROM users WHERE role = 'farm_owner' LIMIT 1");
$farm = $ownerStmt->fetch();

// Stock list
$stockStmt = $pdo->query('SELECT * FROM stock ORDER BY crop_name ASC');
$stocks = $stockStmt->fetchAll();

// Price feed
$priceStmt = $pdo->query('SELECT * FROM price_feed ORDER BY crop_name ASC');
$prices = $priceStmt->fetchAll();

// Weather
$weather = getWeatherAdvisory();

require_once __DIR__ . '/includes/header.php';
?>

<?php if ($farm): ?>
  <section class="farm-banner">
    <h1>
      <?= htmlspecialchars($farm['farm_name']) ?>
    </h1>
    <p class="location">📍
      <?= htmlspecialchars($farm['farm_location']) ?>
    </p>
    <p class="desc">
      <?= htmlspecialchars($farm['farm_description']) ?>
    </p>
    <p class="managed">Managed by
      <?= htmlspecialchars($farm['full_name']) ?>
    </p>
  </section>
<?php endif; ?>

<div class="grid-2">
  <!-- Weather Advisory -->
  <div class="card weather-widget">
    <h2>🌤 Weather Advisory</h2>
    <?php if (!empty($weather['success'])): ?>
      <p class="advisory">
        <?= htmlspecialchars($weather['advisory']) ?>
      </p>
      <p class="weather-meta">
        Location:
        <?= htmlspecialchars($weather['city'] ?? WEATHER_CITY) ?>
        <?php if (isset($weather['avg_temp'])): ?> · Avg ~
          <?= $weather['avg_temp'] ?>°C
        <?php endif; ?>
      </p>
    <?php else: ?>
      <p class="advisory">
        <?= htmlspecialchars($weather['advisory'] ?? 'Weather data unavailable.') ?>
      </p>
      <?php if (!empty($weather['error'])): ?>
        <p class="weather-meta">
          <?= htmlspecialchars($weather['error']) ?>
        </p>
      <?php endif; ?>
    <?php endif; ?>
  </div>

  <!-- Reference Prices -->
  <div class="card">
    <h2>💰 MAO Reference Prices</h2>
    <?php if (empty($prices)): ?>
      <p class="text-muted">No reference prices available yet.</p>
    <?php else: ?>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Crop</th>
              <th>Ref. Price</th>
              <th>Unit</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($prices as $p): ?>
              <tr>
                <td>
                  <?= htmlspecialchars($p['crop_name']) ?>
                </td>
                <td>
                  <?= formatPeso($p['reference_price']) ?>
                </td>
                <td>/
                  <?= htmlspecialchars($p['unit']) ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<!-- Stock listing -->
<section class="card mt-2">
  <h2 class="section-title">Available Stock</h2>
  <div class="search-bar">
    <input type="text" id="stockSearch" class="form-control" placeholder="Search crops…">
  </div>

  <?php if (empty($stocks)): ?>
    <p class="empty-state">No stock items listed yet.</p>
  <?php else: ?>
    <div class="stock-list">
      <?php foreach ($stocks as $s):
        $status = computeStockStatus((float) $s['quantity'], (float) $s['low_stock_threshold']);
        ?>
        <div class="stock-item" data-crop="<?= htmlspecialchars($s['crop_name']) ?>">
          <div class="info">
            <h3>
              <?= htmlspecialchars($s['crop_name']) ?>
            </h3>
            <p class="meta">
              <?= formatPeso($s['price']) ?> /
              <?= htmlspecialchars($s['unit']) ?>
              · Qty:
              <?= number_format((float) $s['quantity'], 2) ?>
              <?= htmlspecialchars($s['unit']) ?>
              · <span class="badge <?= statusBadgeClass($status) ?>">
                <?= $status ?>
              </span>
            </p>
          </div>
          <div class="actions">
            <a href="<?= BASE_URL ?>/order.php?stock_id=<?= (int) $s['stock_id'] ?>" class="btn btn-primary btn-sm">View /
              Order</a>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>