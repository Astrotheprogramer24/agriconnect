/**
 * AgriConnect frontend helpers
 */
document.addEventListener('DOMContentLoaded', function () {
    // Mobile nav toggle
    const toggle = document.getElementById('navToggle');
    const nav = document.getElementById('mainNav');
    if (toggle && nav) {
        toggle.addEventListener('click', function () {
            nav.classList.toggle('open');
        });
    }

    // Confirm before status changes that restore stock
    document.querySelectorAll('[data-confirm]').forEach(function (el) {
        el.addEventListener('submit', function (e) {
            const msg = el.getAttribute('data-confirm');
            if (msg && !confirm(msg)) {
                e.preventDefault();
            }
        });
    });

    // Client-side quantity validation on order form
    const orderForm = document.getElementById('orderForm');
    if (orderForm) {
        const qtyInput = orderForm.querySelector('[name="quantity"]');
        const maxQty = parseFloat(orderForm.dataset.maxQty || '0');
        if (qtyInput) {
            qtyInput.addEventListener('input', function () {
                const val = parseFloat(this.value);
                const err = document.getElementById('qtyError');
                if (val > maxQty) {
                    if (err) err.textContent = 'Cannot exceed available quantity (' + maxQty + ').';
                    this.setCustomValidity('Exceeds available stock');
                } else if (val <= 0) {
                    if (err) err.textContent = 'Quantity must be greater than zero.';
                    this.setCustomValidity('Invalid quantity');
                } else {
                    if (err) err.textContent = '';
                    this.setCustomValidity('');
                }
            });
        }
    }

    // Simple client-side search filter on homepage
    const searchInput = document.getElementById('stockSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function () {
            const q = this.value.toLowerCase().trim();
            document.querySelectorAll('[data-crop]').forEach(function (row) {
                const name = (row.getAttribute('data-crop') || '').toLowerCase();
                row.style.display = name.includes(q) ? '' : 'none';
            });
        });
    }
});
