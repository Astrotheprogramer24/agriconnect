<?php
/**
 * AgriConnect Configuration
 * Adjust these values for your local XAMPP/WAMP environment.
 */

if (!defined('DB_HOST')) {
  define('DB_HOST', 'localhost');
  define('DB_NAME', 'agriconnect');
  define('DB_USER', 'root');
  define('DB_PASS', ''); // default XAMPP password is empty
}

// OpenWeatherMap API key (get free key at https://openweathermap.org/api)
if (!defined('OPENWEATHER_API_KEY')) {
  define('OPENWEATHER_API_KEY', ''); // paste your key here
}

if (!defined('WEATHER_CITY')) {
  define('WEATHER_CITY', 'Cabanatuan');
  define('WEATHER_COUNTRY', 'PH');
  define('WEATHER_LAT', 15.4865);
  define('WEATHER_LON', 120.9675);
  define('WEATHER_CACHE_SECONDS', 600);
}

if (!defined('SESSION_NAME')) {
  define('SESSION_NAME', 'agriconnect_session');
}

/**
 * BASE_URL — must match your folder path under htdocs
 * Examples:
 *   /agriconnect
 *   /AgriConnect/agriconnectv2
 *   ''  (if project is directly in htdocs root)
 */
if (!defined('BASE_URL')) {
  define('BASE_URL', '/Project');
}

if (!defined('SITE_NAME')) {
  define('SITE_NAME', 'AgriConnect');
}

date_default_timezone_set('Asia/Manila');
error_reporting(E_ALL);
ini_set('display_errors', 1);
