<?php
/**
 * Session-based authentication, role helpers, notifications
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
  session_name(SESSION_NAME);
  session_start();
}

function isLoggedIn(): bool
{
  return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function currentUser(): ?array
{
  if (!isLoggedIn())
    return null;
  static $user = null;
  if ($user === null) {
    $pdo = getDB();
    $stmt = $pdo->prepare('SELECT * FROM users WHERE user_id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch() ?: null;
    if (!$user) {
      logout();
      return null;
    }
  }
  return $user;
}

function currentRole(): ?string
{
  $u = currentUser();
  return $u ? $u['role'] : null;
}

function requireLogin(): void
{
  if (!isLoggedIn()) {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
  }
}

function requireRole(string $role): void
{
  requireLogin();
  if (currentRole() !== $role) {
    redirectToDashboard();
  }
}

function redirectToDashboard(): void
{
  $role = currentRole();
  switch ($role) {
    case 'farm_owner':
      header('Location: ' . BASE_URL . '/dashboard.php');
      break;
    case 'admin':
      header('Location: ' . BASE_URL . '/admin_prices.php');
      break;
    case 'buyer':
      header('Location: ' . BASE_URL . '/my_orders.php');
      break;
    default:
      header('Location: ' . BASE_URL . '/index.php');
  }
  exit;
}

function login(string $email, string $password): array
{
  $pdo = getDB();
  $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
  $stmt->execute([trim($email)]);
  $user = $stmt->fetch();

  if (!$user || !password_verify($password, $user['password_hash'])) {
    return ['success' => false, 'error' => 'Invalid email or password.'];
  }

  session_regenerate_id(true);
  $_SESSION['user_id'] = $user['user_id'];
  $_SESSION['role'] = $user['role'];
  $_SESSION['full_name'] = $user['full_name'];

  return ['success' => true, 'user' => $user];
}

function logout(): void
{
  $_SESSION = [];
  if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
  }
  session_destroy();
}

function registerBuyer(string $fullName, string $email, string $password, string $contact): array
{
  $pdo = getDB();

  $stmt = $pdo->prepare('SELECT user_id FROM users WHERE email = ?');
  $stmt->execute([trim($email)]);
  if ($stmt->fetch()) {
    return ['success' => false, 'error' => 'Email is already registered.'];
  }

  $hash = password_hash($password, PASSWORD_BCRYPT);
  $stmt = $pdo->prepare(
    'INSERT INTO users (full_name, email, password_hash, contact_number, role) VALUES (?, ?, ?, ?, ?)'
  );
  $stmt->execute([trim($fullName), trim($email), $hash, trim($contact), 'buyer']);

  return ['success' => true, 'user_id' => (int) $pdo->lastInsertId()];
}

function computeStockStatus(float $quantity, float $threshold): string
{
  if ($quantity <= 0)
    return 'out of stock';
  if ($quantity <= $threshold)
    return 'low stock';
  return 'available';
}

function statusBadgeClass(string $status): string
{
  switch (strtolower($status)) {
    case 'available':
      return 'badge-success';
    case 'low stock':
      return 'badge-warning';
    case 'out of stock':
      return 'badge-danger';
    case 'pending':
      return 'badge-info';
    case 'confirmed':
      return 'badge-primary';
    case 'fulfilled':
      return 'badge-success';
    case 'cancelled':
      return 'badge-secondary';
    case 'open':
      return 'badge-info';
    case 'replied':
      return 'badge-success';
    case 'closed':
      return 'badge-secondary';
    default:
      return 'badge-secondary';
  }
}

function formatPeso($amount): string
{
  return '₱' . number_format((float) $amount, 2);
}

/**
 * Create a notification record (structured for future SMS/email gateway)
 */
function createNotification(int $userId, string $type, string $message, string $channel = 'in_app'): void
{
  try {
    $pdo = getDB();
    $stmt = $pdo->prepare(
      'INSERT INTO notifications (user_id, type, message, channel) VALUES (?, ?, ?, ?)'
    );
    $stmt->execute([$userId, $type, $message, $channel]);

    // Attempt email notification if channel is email (uses PHP mail — works if server mail is configured)
    if ($channel === 'email') {
      $u = $pdo->prepare('SELECT email, full_name FROM users WHERE user_id = ?');
      $u->execute([$userId]);
      $row = $u->fetch();
      if ($row) {
        $subject = '[AgriConnect] ' . ucfirst(str_replace('_', ' ', $type));
        $body = "Hello {$row['full_name']},\n\n{$message}\n\n— AgriConnect System";
        @mail($row['email'], $subject, $body, 'From: noreply@agriconnect.local');
      }
    }
  } catch (Exception $e) {
    // fail silently — notifications should not break main flow
  }
}

function getFarmOwnerId(): ?int
{
  $pdo = getDB();
  $stmt = $pdo->query("SELECT user_id FROM users WHERE role = 'farm_owner' LIMIT 1");
  $row = $stmt->fetch();
  return $row ? (int) $row['user_id'] : null;
}
