</div><!-- /.container -->
</main>
<footer class="site-footer">
  <div class="container">
    <p>&copy; <?= date('Y') ?> AgriConnect — Online Stock & Order Management for Farms</p>
    <p class="footer-sdg">Supporting SDG 2 (Zero Hunger) &amp; SDG 8 (Decent Work and Economic Growth)</p>
  </div>
</footer>
<script src="<?= BASE_URL ?>/assets/js/app.js"></script>
</body>

</html>