<?php
if (!isset($pageTitle))
  $pageTitle = 'AgriConnect';
require_once __DIR__ . '/auth.php';
$user = currentUser();
$role = currentRole();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle) ?> | AgriConnect</title>
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>

<body>
  <header class="site-header">
    <div class="container header-inner">
      <a href="<?= BASE_URL ?>/index.php" class="logo">
        <span class="logo-icon">🌱</span>
        <span class="logo-text">AgriConnect</span>
      </a>
      <nav class="main-nav" id="mainNav">
        <a href="<?= BASE_URL ?>/index.php">Farm Store</a>
        <?php if ($role === 'buyer'): ?>
          <a href="<?= BASE_URL ?>/my_orders.php">My Orders</a>
          <a href="<?= BASE_URL ?>/inquiries.php">My Inquiries</a>
        <?php endif; ?>
        <?php if ($role === 'farm_owner'): ?>
          <a href="<?= BASE_URL ?>/dashboard.php">Dashboard</a>
          <a href="<?= BASE_URL ?>/inquiries_owner.php">Inquiries</a>
          <a href="<?= BASE_URL ?>/reports.php">Reports</a>
        <?php endif; ?>
        <?php if ($role === 'admin'): ?>
          <a href="<?= BASE_URL ?>/admin_prices.php">Price Feed</a>
        <?php endif; ?>
        <?php if ($user): ?>
          <span class="nav-user">Hi, <?= htmlspecialchars($user['full_name']) ?></span>
          <a href="<?= BASE_URL ?>/logout.php" class="btn btn-outline btn-sm">Logout</a>
        <?php else: ?>
          <a href="<?= BASE_URL ?>/login.php">Login</a>
          <a href="<?= BASE_URL ?>/register.php" class="btn btn-primary btn-sm">Register</a>
        <?php endif; ?>
      </nav>
      <button class="nav-toggle" id="navToggle" aria-label="Toggle menu">☰</button>
    </div>
  </header>
  <main class="main-content">
    <div class="container">
      <?php
      if (!empty($_SESSION['flash_success'])) {
        echo '<div class="alert alert-success">' . htmlspecialchars($_SESSION['flash_success']) . '</div>';
        unset($_SESSION['flash_success']);
      }
      if (!empty($_SESSION['flash_error'])) {
        echo '<div class="alert alert-error">' . htmlspecialchars($_SESSION['flash_error']) . '</div>';
        unset($_SESSION['flash_error']);
      }
      ?>