<?php
/**
 * Weather Module — server-side OpenWeatherMap integration with simple caching
 */
require_once __DIR__ . '/config.php';

function getWeatherAdvisory(): array
{
  $cacheFile = sys_get_temp_dir() . '/agriconnect_weather_cache.json';
  $now = time();

  // Serve from cache if still valid
  if (file_exists($cacheFile)) {
    $cached = json_decode(file_get_contents($cacheFile), true);
    if ($cached && isset($cached['fetched_at']) && ($now - $cached['fetched_at']) < WEATHER_CACHE_SECONDS) {
      return $cached;
    }
  }

  if (empty(OPENWEATHER_API_KEY)) {
    return [
      'success' => false,
      'error' => 'Weather API key is not configured. Add your OpenWeatherMap key in includes/config.php.',
      'advisory' => 'Weather data unavailable — configure API key to receive harvest advisories.',
      'fetched_at' => $now,
    ];
  }

  // Use 5-day / 3-hour forecast endpoint
  $url = sprintf(
    'https://api.openweathermap.org/data/2.5/forecast?lat=%s&lon=%s&units=metric&appid=%s',
    urlencode((string) WEATHER_LAT),
    urlencode((string) WEATHER_LON),
    urlencode(OPENWEATHER_API_KEY)
  );

  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 10,
    CURLOPT_FOLLOWLOCATION => true,
  ]);
  $response = curl_exec($ch);
  $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  $curlError = curl_error($ch);
  curl_close($ch);

  if ($response === false || $httpCode !== 200) {
    $msg = $curlError ?: "HTTP $httpCode";
    return [
      'success' => false,
      'error' => 'Weather request failed: ' . $msg,
      'advisory' => 'Unable to retrieve weather forecast at this time. Please try again later.',
      'fetched_at' => $now,
    ];
  }

  $data = json_decode($response, true);
  if (!$data || !isset($data['list'])) {
    return [
      'success' => false,
      'error' => 'Invalid weather response.',
      'advisory' => 'Weather data could not be parsed.',
      'fetched_at' => $now,
    ];
  }

  // Analyse next 24–48 hours for rain probability and conditions
  $highRainChance = false;
  $maxPop = 0;
  $temps = [];
  $descriptions = [];
  $cityName = $data['city']['name'] ?? WEATHER_CITY;

  $limit = min(16, count($data['list'])); // ~48 hours
  for ($i = 0; $i < $limit; $i++) {
    $item = $data['list'][$i];
    $pop = isset($item['pop']) ? (float) $item['pop'] : 0;
    if ($pop > $maxPop)
      $maxPop = $pop;
    if ($pop >= 0.5)
      $highRainChance = true;
    if (isset($item['main']['temp']))
      $temps[] = (float) $item['main']['temp'];
    if (isset($item['weather'][0]['description'])) {
      $descriptions[] = $item['weather'][0]['description'];
    }
  }

  $avgTemp = $temps ? round(array_sum($temps) / count($temps), 1) : null;
  $commonDesc = $descriptions ? $descriptions[0] : 'variable conditions';

  // Plain-language advisory
  $advisoryParts = [];
  $advisoryParts[] = "Forecast for {$cityName}: mostly {$commonDesc}.";
  if ($avgTemp !== null) {
    $advisoryParts[] = "Average temperature around {$avgTemp}°C over the next 2 days.";
  }
  if ($highRainChance) {
    $pct = round($maxPop * 100);
    $advisoryParts[] = "High chance of rain (up to {$pct}%). Consider harvesting sensitive crops earlier and protecting newly listed stock from moisture.";
  } else {
    $advisoryParts[] = "Rain probability is low. Good window for field work and listing fresh produce.";
  }

  $result = [
    'success' => true,
    'city' => $cityName,
    'avg_temp' => $avgTemp,
    'max_pop' => $maxPop,
    'high_rain' => $highRainChance,
    'description' => $commonDesc,
    'advisory' => implode(' ', $advisoryParts),
    'fetched_at' => $now,
    'raw_sample' => array_slice($data['list'], 0, 3), // small sample for debugging
  ];

  // Cache it
  @file_put_contents($cacheFile, json_encode($result));

  return $result;
}
