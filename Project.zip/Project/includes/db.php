a
<?php
/**
 * Database connection using PDO (prepared statements)
 */
require_once __DIR__ . '/config.php';

function getDB(): PDO
{
  static $pdo = null;
  if ($pdo === null) {
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $options = [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
      PDO::ATTR_EMULATE_PREPARES => false,
    ];
    try {
      $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
      die('Database connection failed. Please check includes/config.php and ensure the database is created. Error: ' . htmlspecialchars($e->getMessage()));
    }
  }
  return $pdo;
}
